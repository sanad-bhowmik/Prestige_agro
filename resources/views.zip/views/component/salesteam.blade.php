<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="{{ asset('img/PADLogo.png') }}">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <title>Prestige</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Nunito', sans-serif;
        }

        .max-w-7xl {
            margin-top: 5rem;
        }
    </style>
</head>

<body class="antialiased">
    @include('partials.nav')

    <!-- Table Section -->
    <div class="max-w-7xl mx-auto py-4 px-6">
        <h2 class="text-2xl font-bold text-gray-800 mb-6">Sample Data Table</h2>
        <div class="overflow-x-auto bg-white shadow-lg rounded-lg">
            <table class="min-w-full text-sm text-left text-gray-500">
                <thead class="bg-gray-100 text-xs text-gray-700 uppercase">
                    <tr>
                        <th class="px-6 py-4">ID</th>
                        <th class="px-6 py-4">Name</th>
                        <th class="px-6 py-4">Role</th>
                        <th class="px-6 py-4">Date Joined</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="bg-white border-b">
                        <td class="px-6 py-4">1</td>
                        <td class="px-6 py-4">John Doe</td>
                        <td class="px-6 py-4">Admin</td>
                        <td class="px-6 py-4">2022-01-15</td>
                    </tr>
                    <tr class="bg-gray-50 border-b">
                        <td class="px-6 py-4">2</td>
                        <td class="px-6 py-4">Jane Smith</td>
                        <td class="px-6 py-4">Editor</td>
                        <td class="px-6 py-4">2021-12-10</td>
                    </tr>
                    <tr class="bg-white border-b">
                        <td class="px-6 py-4">3</td>
                        <td class="px-6 py-4">Michael Johnson</td>
                        <td class="px-6 py-4">Subscriber</td>
                        <td class="px-6 py-4">2023-03-01</td>
                    </tr>
                    <tr class="bg-gray-50">
                        <td class="px-6 py-4">4</td>
                        <td class="px-6 py-4">Emily Davis</td>
                        <td class="px-6 py-4">Editor</td>
                        <td class="px-6 py-4">2022-06-18</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    @include('partials.footer')
</body>

<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

</html>
