<div style="height:2vh;background-color:#05a854;"></div>
<nav class="bg-white border-b border-gray-200 dark:bg-gray-900 dark:border-gray-800 shadow-sm">
    <div class="max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16 items-center">
            <!-- Logo -->
            <div class="flex-shrink-0 flex items-center">
                <a href="http://prestigeagro.com/" class="flex items-center space-x-2">
                    <img src="{{ asset('img/logo.jpg') }}" class="h-10 w-auto" alt="Prestige Agro Logo" />
                </a>
            </div>

            <!-- Desktop Navigation -->
            <div class="hidden md:flex md:items-center md:space-x-6">
                <a href="/" class="px-1 pt-1 pb-2 border-b-2 border-transparent text-sm font-medium text-gray-700 hover:text-green-600 dark:text-gray-300 dark:hover:text-green-400 transition-colors duration-300 hover:border-green-500">Home</a>

                <!-- Products Dropdown -->
                <div class="relative group" id="productsDropdown">
                    <button class="flex items-center px-1 pt-1 pb-2 border-b-2 border-transparent text-sm font-medium text-gray-700 hover:text-green-600 dark:text-gray-300 dark:hover:text-green-400 transition-colors duration-300">
                        <span>Products</span>
                        <svg class="ml-1 h-4 w-4 transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>

                    <!-- Dropdown Panel -->
                    <div id="productsDropdownPanel" class="absolute z-20 -ml-4 mt-2 transform px-2 w-56 max-w-md sm:px-0 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 ease-out">
                        <div class="rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 overflow-hidden">
                            <div class="relative grid gap-1 bg-white dark:bg-gray-800 p-2">
                                <a href="/insecticide" class="flex items-start px-3 py-2 rounded-lg hover:bg-green-50 dark:hover:bg-gray-700 transition-colors duration-150">
                                    <div class="flex-shrink-0 h-5 w-5 text-green-500">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                                        </svg>
                                    </div>
                                    <div class="ml-3">
                                        <p class="text-sm font-medium text-gray-900 dark:text-gray-100">Insecticide</p>
                                    </div>
                                </a>
                                <a href="/fungicide" class="flex items-start px-3 py-2 rounded-lg hover:bg-green-50 dark:hover:bg-gray-700 transition-colors duration-150">
                                    <div class="flex-shrink-0 h-5 w-5 text-green-500">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                        </svg>
                                    </div>
                                    <div class="ml-3">
                                        <p class="text-sm font-medium text-gray-900 dark:text-gray-100">Fungicide</p>
                                    </div>
                                </a>
                                <a href="/herbicide" class="flex items-start px-3 py-2 rounded-lg hover:bg-green-50 dark:hover:bg-gray-700 transition-colors duration-150">
                                    <div class="flex-shrink-0 h-5 w-5 text-green-500">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                                        </svg>
                                    </div>
                                    <div class="ml-3">
                                        <p class="text-sm font-medium text-gray-900 dark:text-gray-100">Herbicide</p>
                                    </div>
                                </a>
                                <a href="/micronutrients" class="flex items-start px-3 py-2 rounded-lg hover:bg-green-50 dark:hover:bg-gray-700 transition-colors duration-150">
                                    <div class="flex-shrink-0 h-5 w-5 text-green-500">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                                        </svg>
                                    </div>
                                    <div class="ml-3">
                                        <p class="text-sm font-medium text-gray-900 dark:text-gray-100">Micronutrients Fertilizer</p>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <a href="/salesteam" class="px-1 pt-1 pb-2 border-b-2 border-transparent text-sm font-medium text-gray-700 hover:text-green-600 dark:text-gray-300 dark:hover:text-green-400 transition-colors duration-300 hover:border-green-500">Sales Officer</a>
                <a href="/team" class="px-1 pt-1 pb-2 border-b-2 border-transparent text-sm font-medium text-gray-700 hover:text-green-600 dark:text-gray-300 dark:hover:text-green-400 transition-colors duration-300 hover:border-green-500">Our Team</a>
                <a href="/contact" class="px-1 pt-1 pb-2 border-b-2 border-transparent text-sm font-medium text-gray-700 hover:text-green-600 dark:text-gray-300 dark:hover:text-green-400 transition-colors duration-300 hover:border-green-500">Contact Us</a>
            </div>

            <!-- Right side buttons -->
            <div class="flex items-center space-x-3">
                <!-- Download Button -->
                <a href="{{ asset('img/prospectus cmyk.pdf') }}" download class="hidden md:flex items-center px-3 py-2 rounded-md text-sm font-medium text-white  shadow-sm transition-colors duration-300">
                    <img src="{{ asset('img/pdf.png') }}" alt="Download Icon" class="h-6 w-6 mr-2" />

                </a>

                 <!-- Language Selection -->
                <div class="flex items-center space-x-2 text-sm text-gray-700 dark:text-gray-300">
                    <span>Language:</span>
                    <select class="bg-transparent dark:bg-gray-700 text-gray-900 dark:text-gray-100">
                        <option value="en">English</option>
                        <option value="es">Español</option>
                        <option value="fr">Français</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
</nav>

<script>
    const productsDropdown = document.getElementById("productsDropdown");
    const productsDropdownPanel = document.getElementById("productsDropdownPanel");

    // Add mouseover event to show dropdown
    productsDropdown.addEventListener('mouseenter', function() {
        productsDropdownPanel.style.opacity = '1';
        productsDropdownPanel.style.visibility = 'visible';
    });

    // Add mouseleave event to hide dropdown
    productsDropdown.addEventListener('mouseleave', function() {
        productsDropdownPanel.style.opacity = '0';
        productsDropdownPanel.style.visibility = 'hidden';
    });
</script>
