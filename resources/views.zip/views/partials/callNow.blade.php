<section class="relative overflow-hidden py-20 md:py-32 px-4 mb-10" 
    style="background-image: url('https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=2070&auto=format&fit=crop'); background-attachment: fixed; background-size: cover; background-position: center;">

    <!-- Dark overlay -->
    <div class="absolute inset-0 bg-black/60 z-0"></div>
    
    <!-- Animated gradient border effect -->
    <div class="absolute inset-0 overflow-hidden z-0">
        <div class="absolute -top-[50%] -left-[50%] w-[200%] h-[200%] animate-spin-slow">
            <div class="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-400/20 to-transparent"></div>
        </div>
    </div>
    
    <!-- Floating particles -->
    <div class="absolute inset-0 z-0 overflow-hidden">
        <div class="particle absolute rounded-full bg-yellow-400/30"></div>
        <div class="particle absolute rounded-full bg-yellow-400/20"></div>
        <div class="particle absolute rounded-full bg-yellow-400/10"></div>
        <!-- More particles would be added via JavaScript -->
    </div>
    
    <!-- Main content container -->
    <div class="container mx-auto relative z-10">
        <div class="max-w-3xl mx-auto text-center px-4">
            <!-- Animated heading -->
            <h1 class="text-4xl md:text-6xl font-bold mb-6 text-white animate-fade-in-up">
                <span class="text-green-400">Need Immediate</span> Assistance?
            </h1>
            
            <!-- Glowing subtitle -->
            <p class="text-xl md:text-2xl mb-10 text-white/90 font-medium animate-fade-in-up delay-100">
                Our team is ready to provide fast support and expert solutions
            </p>
            
            <!-- Animated call-to-action button -->
            <div class="animate-fade-in-up delay-200">
                <a href="tel:+880174 0630671" class="inline-flex items-center justify-center gap-3 bg-gradient-to-r from-green-400 to-green-500 text-black font-bold py-5 px-10 rounded-full hover:shadow-lg hover:shadow-yellow-400/30 transition-all duration-300 transform hover:-translate-y-1">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                    Call Now: +880 174 063 0671
                </a>
            </div>
            
            <!-- Additional contact option -->
            <p class="mt-8 text-white/80 animate-fade-in-up delay-300">
                Or email us at <a href="mailto:prestigeagrodragonltd@gmail.com" class="text-yellow-400 hover:underline">prestigeagrodragonltd@gmail.com</a>
            </p>
        </div>
    </div>
</section>

<style>
    /* Animation keyframes */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    @keyframes spin {
        from {
            transform: rotate(0deg);
        }
        to {
            transform: rotate(360deg);
        }
    }
    
    /* Animation classes */
    .animate-fade-in-up {
        animation: fadeInUp 0.8s ease-out forwards;
    }
    
    .animate-spin-slow {
        animation: spin 20s linear infinite;
    }
    
    .delay-100 {
        animation-delay: 0.1s;
    }
    
    .delay-200 {
        animation-delay: 0.2s;
    }
    
    .delay-300 {
        animation-delay: 0.3s;
    }
    
    /* Particle animation */
    .particle {
        animation: float 15s infinite ease-in-out;
    }
    
    @keyframes float {
        0%, 100% {
            transform: translate(0, 0);
        }
        25% {
            transform: translate(20px, 20px);
        }
        50% {
            transform: translate(0, 40px);
        }
        75% {
            transform: translate(-20px, 20px);
        }
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
        h1 {
            font-size: 2.5rem;
        }
        
        p {
            font-size: 1.1rem;
        }
        
        a {
            padding: 0.75rem 1.5rem;
            font-size: 1rem;
        }
    }
</style>

<script>
    // Add dynamic particles (optional)
    document.addEventListener('DOMContentLoaded', function() {
        const particlesContainer = document.querySelector('.particles-container');
        for (let i = 0; i < 10; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle absolute rounded-full bg-yellow-400/' + (10 + Math.random() * 20);
            particle.style.width = (2 + Math.random() * 8) + 'px';
            particle.style.height = particle.style.width;
            particle.style.left = Math.random() * 100 + '%';
            particle.style.top = Math.random() * 100 + '%';
            particle.style.animationDuration = (10 + Math.random() * 20) + 's';
            particle.style.animationDelay = Math.random() * 5 + 's';
            particlesContainer.appendChild(particle);
        }
    });
</script>